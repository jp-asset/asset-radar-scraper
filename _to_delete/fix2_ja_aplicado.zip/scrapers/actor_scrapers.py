"""
Scrapers que usam actors prontos do Apify marketplace.
Zero manutencao de seletores — os autores dos actors mantem-nos actualizados.

NOTA: run_actor() usa client.run(run.id).dataset() — compativel com apify-client 3.x
"""
import logging
import time
from datetime import timedelta
from core.apify_client import get_apify_client, MAX_RESULTS_PER_SOURCE
from core.models import Listing
from core.normalize import parse_price, parse_area, clean_text
from core.config import ZONE_PRICES_DEFAULT

log = logging.getLogger("asset_radar")


def run_actor(actor_id: str, run_input: dict, timeout_secs: int = 180) -> list[dict]:
    """
    Corre um actor do Apify e devolve os resultados como lista de dicts.
    Usa client.run(run.id).dataset() — forma correcta no apify-client 3.x.
    O objeto devolvido por actor.call() e um Run, nao um dict.
    """
    client = get_apify_client()
    log.info(f"[Apify] A correr actor {actor_id} (max {MAX_RESULTS_PER_SOURCE} resultados)")
    start = time.time()
    try:
        run = client.actor(actor_id).call(
            run_input=run_input,
            memory_mbytes=256,
            wait_duration=timedelta(seconds=timeout_secs),
        )
        if run is None:
            log.warning(f"[Apify] {actor_id}: run devolveu None (timeout?)")
            return []
        elapsed = round(time.time() - start, 1)
        items = list(client.run(run.id).dataset().iterate_items())
        log.info(f"[Apify] {actor_id}: {len(items)} resultados em {elapsed}s")
        return items
    except Exception as e:
        elapsed = round(time.time() - start, 1)
        log.error(f"[Apify] {actor_id} falhou apos {elapsed}s: {e}")
        return []


class ImovirtualActorScraper:
    """
    Actor: solidcode/imovirtual-scraper

    CALIBRADO 17/08/2026 — dois bugs no input confirmados contra o input schema
    publicado (apify.com/solidcode/imovirtual-scraper/input-schema):
      1. `location` tem de ser o nome da cidade/região em português com
         acentos (ex: "Lisboa"), não um slug em minúsculas ("lisboa") — o
         actor não faz essa normalização.
      2. `propertyType` é enum fechado: any/apartment/house/land/commercial/
         garage/room/warehouse/development. "apartamento" não é um valor
         válido, pelo que era provavelmente ignorado ou rejeitado — devolvia
         0 resultados. Corrigido para "apartment".
    """
    portal_name = "Imovirtual"
    category = "imovel"
    actor_id = "solidcode/imovirtual-scraper"

    def run(self, zones: list[str]) -> list[Listing]:
        listings = []
        for zone in zones[:2]:
            location = {"Lisboa Centro": "Lisboa", "Porto Centro": "Porto",
                        "Cascais": "Cascais"}.get(zone, "Lisboa")
            items = run_actor(self.actor_id, {
                "location": location,
                "transaction": "buy",
                "propertyType": "apartment",
                "maxResults": MAX_RESULTS_PER_SOURCE,
            })
            for item in items:
                price = parse_price(item.get("price") or item.get("totalPrice"))
                area = parse_area(item.get("area") or item.get("livingArea"))
                url = item.get("url", "")
                title = clean_text(item.get("title") or f"Apartamento {zone}")
                if not url:
                    continue
                ppm2 = ZONE_PRICES_DEFAULT.get(zone, 5000)
                market = ppm2 * area if area else None
                listings.append(Listing(
                    portal=self.portal_name, category=self.category,
                    external_id=url, title=title, price=price,
                    market_estimate=market, currency="EUR", url=url,
                    zone=zone, area_m2=area,
                    posted_date=item.get("dateCreated"),
                    details={
                        "tipologia": item.get("rooms", ""),
                        "casas_banho": item.get("bathrooms", ""),
                        "fonte_raw": "imovirtual_actor",
                    },
                ))
        return listings


class IdealistaActorScraper:
    """
    Actor: lukass/idealista-scraper

    CALIBRADO 17/08/2026 — três problemas identificados contra a documentação
    pública do actor:
      1. Nomes de campo errados: o schema usa `startUrl` (singular) e
         `maxItems`, não `startUrls`/`maxResults` — os valores enviados
         eram provavelmente ignorados por não corresponderem a nenhum campo.
      2. `propertyType: "homes"` não existe no schema deste actor (schema
         tem `homeType`, não `propertyType`) — removido.
      3. A documentação do actor indica explicitamente "RESIDENTIAL proxies
         required" e não estávamos a enviar nenhuma config de proxy — isto é
         a explicação mais provável para os timeouts (o actor fica bloqueado
         pelo anti-bot da Idealista sem proxy residencial e nunca devolve
         dados dentro do tempo limite).

    ⚠️ POR VALIDAR: não consegui confirmar o nome exacto do campo de proxy
    (usei `proxyConfiguration` — é a convenção standard do Apify SDK, mas
    este actor pode ter um nome custom). Também não confirmei se
    `startUrl` espera string simples ou {"url": ...}. Recomendo um scan de
    teste manual (Actions → Run workflow) antes de confiar nisto no cron
    diário — ver nota de custo abaixo.
    """
    portal_name = "Idealista"
    category = "imovel"
    actor_id = "lukass/idealista-scraper"

    def run(self, zones: list[str]) -> list[Listing]:
        items = run_actor(self.actor_id, {
            "country": "pt",
            "operation": "sale",
            "startUrl": [{"url": "https://www.idealista.pt/comprar-casas/lisboa/"}],
            "maxItems": MAX_RESULTS_PER_SOURCE,
            "proxyConfiguration": {"useApifyProxy": True, "apifyProxyGroups": ["RESIDENTIAL"]},
        }, timeout_secs=240)
        listings = []
        for item in items:
            price = parse_price(item.get("price"))
            area = parse_area(item.get("size"))
            url = item.get("url", "")
            title = clean_text(item.get("title") or item.get("description", "")[:60])
            if not url:
                continue
            zone = item.get("district") or item.get("neighborhood") or "Lisboa"
            ppm2 = ZONE_PRICES_DEFAULT.get(zone, 5000)
            market = ppm2 * area if area else None
            listings.append(Listing(
                portal=self.portal_name, category=self.category,
                external_id=url, title=title, price=price,
                market_estimate=market, currency="EUR", url=url,
                zone=zone, area_m2=area,
                details={"fonte_raw": "idealista_actor"},
            ))
        return listings


class OLXActorScraper:
    """Actor: piotrv1001/olx-listings-scraper"""
    portal_name = "OLX"
    category = "geral"
    actor_id = "piotrv1001/olx-listings-scraper"

    def run(self, zones: list[str]) -> list[Listing]:
        items = run_actor(self.actor_id, {
            "startUrls": [{"url": "https://www.olx.pt/imoveis/"}],
            "maxItems": MAX_RESULTS_PER_SOURCE,
            "country": "pt",
        })
        listings = []
        for item in items:
            price = parse_price(item.get("price"))
            url = item.get("url", "")
            title = clean_text(item.get("title", ""))
            if not url or not title:
                continue
            listings.append(Listing(
                portal=self.portal_name, category="imovel",
                external_id=url, title=title, price=price,
                market_estimate=price * 1.15 if price else None,
                currency="EUR", url=url,
                posted_date=item.get("createdAt"),
                details={"fonte_raw": "olx_actor"},
            ))
        return listings


class AutoScout24ActorScraper:
    """
    Actor: blackfalcondata/autoscout24-scraper
    Gratuito (so compute units) — substitui 3x1t que expirou.

    CALIBRADO 17/08/2026 — o nome do campo estava errado: a documentação do
    actor só reconhece `searchUrls` para URLs directos (que "sobrepõem todos
    os filtros"); `startUrls` não é um campo válido deste actor, pelo que a
    URL nunca era usada — provavelmente corria com defaults (ou nada).
    Nota: o campo `countries` deste actor nem sequer inclui "PT" no enum
    (só DE/AT/BE/FR/IT/NL/ES/LU) — por isso é essencial continuar a usar
    `searchUrls` com o domínio .pt directo em vez de tentar `countries`.
    """
    portal_name = "AutoScout24"
    category = "carro"
    actor_id = "blackfalcondata/autoscout24-scraper"

    def run(self, zones: list[str]) -> list[Listing]:
        items = run_actor(self.actor_id, {
            "searchUrls": [{"url": "https://www.autoscout24.pt/lst?sort=price&desc=0&ustate=N%2CU&size=20"}],
            "maxResults": MAX_RESULTS_PER_SOURCE,
        })
        listings = []
        for item in items:
            price = parse_price(item.get("price"))
            url = item.get("url") or item.get("portalUrl", "")
            title = clean_text(item.get("title") or item.get("name", ""))
            if not url or not title:
                continue
            listings.append(Listing(
                portal=self.portal_name, category=self.category,
                external_id=url, title=title, price=price,
                market_estimate=price * 1.15 if price else None,
                currency="EUR", url=url,
                details={
                    "km": str(item.get("mileage", "")),
                    "ano": str(item.get("year", "")),
                    "fonte_raw": "autoscout24_actor",
                },
            ))
        return listings


class Chrono24ActorScraper:
    """
    Actor: memo23/chrono24-scraper — usa .com nao .pt

    CALIBRADO 17/08/2026 — o domínio `.com` e os nomes de campo (`startUrls`,
    `maxItems`) já estavam correctos contra a documentação do actor; a nota
    "URL .com não .pt" no registo do projecto estava desactualizada. O risco
    real identificado: por defeito este actor faz `fetchListingDetails=true`
    com `maxIndexPages=10`, um crawl bem mais pesado do que o nosso
    orçamento de 180s/256MB suporta — provável causa do que aparecia como
    "falha de calibração". Limitado explicitamente ao necessário para caber
    no orçamento actual (ver run_actor: timeout_secs=180, memory 256MB).
    """
    portal_name = "Chrono24"
    category = "relogio"
    actor_id = "memo23/chrono24-scraper"

    def run(self, zones: list[str]) -> list[Listing]:
        items = run_actor(self.actor_id, {
            "startUrls": [{"url": "https://www.chrono24.com/rolex/index.htm"}],
            "maxItems": MAX_RESULTS_PER_SOURCE,
            "fetchListingDetails": False,
            "maxIndexPages": 1,
        })
        listings = []
        for item in items:
            price = parse_price(item.get("price"))
            url = item.get("url", "")
            title = clean_text(item.get("title") or item.get("model", ""))
            if not url:
                continue
            listings.append(Listing(
                portal=self.portal_name, category=self.category,
                external_id=url, title=title, price=price,
                market_estimate=price * 1.15 if price else None,
                currency="EUR", url=url,
                details={
                    "marca": item.get("brand", ""),
                    "ref": item.get("reference", ""),
                    "ano": str(item.get("year", "")),
                    "fonte_raw": "chrono24_actor",
                },
            ))
        return listings


class CatawikiActorScraper:
    """
    Actor: solidcode/catawiki-scraper — usa keywords nao startUrls

    CORRIGIDO 17/08/2026 — BUG CRÍTICO: `currentBid` neste actor não é um
    número, é um objecto com as 3 moedas: {"EUR": 6200, "USD": 6700, "GBP": 5300}.
    O código anterior fazia parse_price(item.get("currentBid") or ...), que
    convertia o dicionário inteiro para texto (str({...})) e extraía todos os
    dígitos encontrados — juntando os 3 valores de moeda num único número
    gigante sem sentido (ex: 6200+6700+5300 concatenados = "620067005300").
    Confirmado nos 96 registos reais do scan de hoje: preços na ordem dos
    600 mil milhões de euros para relógios Rolex. Corrigido para ler
    especificamente currentBid['EUR'], com fallback para currentBidValue
    quando a moeda já vem em EUR.
    """
    portal_name = "Catawiki"
    category = "arte"
    actor_id = "solidcode/catawiki-scraper"

    def run(self, zones: list[str]) -> list[Listing]:
        items = run_actor(self.actor_id, {
            "keywords": ["art", "painting", "sculpture"],
            "maxItems": MAX_RESULTS_PER_SOURCE,
        }, timeout_secs=240)
        listings = []
        for item in items:
            bid = item.get("currentBid")
            if isinstance(bid, dict):
                raw_price = bid.get("EUR")
            elif item.get("currentBidCurrency") == "EUR":
                raw_price = item.get("currentBidValue")
            else:
                raw_price = item.get("price")  # último recurso, pode não existir
            price = parse_price(raw_price)
            url = item.get("url", "")
            title = clean_text(item.get("title", ""))
            if not url or not title:
                continue
            listings.append(Listing(
                portal=self.portal_name, category=self.category,
                external_id=url, title=title, price=price,
                # NOTA: *1.15 é uma estimativa genérica de mercado (não há
                # preço de referência real para arte/leilões, ao contrário do
                # imobiliário que usa €/m² por zona) — por isso dá sempre
                # ~13% de "desconto", o que NÃO é uma comparação de mercado
                # real. Confiança reduzida para reflectir isso.
                market_estimate=price * 1.15 if price else None,
                currency="EUR", url=url,
                confidence=0.45,
                details={"tipo": "leilao", "fonte_raw": "catawiki_actor",
                         "nota_mercado": "estimativa genérica — sem preço de referência real de leilões"},
            ))
        return listings


ALL_ACTOR_SCRAPERS = [
    ImovirtualActorScraper,
    IdealistaActorScraper,
    OLXActorScraper,
    AutoScout24ActorScraper,
    Chrono24ActorScraper,
    CatawikiActorScraper,
]
